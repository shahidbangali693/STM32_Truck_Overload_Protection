
 

void Cmd4bit(uint8_t cmd) 
{

	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15,  ((cmd & 0x08)? GPIO_PIN_SET : GPIO_PIN_RESET )); //D7
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_9,  ((cmd & 0x04)? GPIO_PIN_SET : GPIO_PIN_RESET )); //D6
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, ((cmd & 0x02)? GPIO_PIN_SET : GPIO_PIN_RESET )); //D5
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, ((cmd & 0x01)? GPIO_PIN_SET : GPIO_PIN_RESET )); //D4
  HAL_Delay(3);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_SET);
	HAL_Delay(3);
	
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET);
	HAL_Delay(3);
 

}
void Cmd(uint8_t cmd)  
{
HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_RESET);//RS pin low
	
Cmd4bit(cmd >> 4);
	 
HAL_Delay(1);

Cmd4bit(cmd & 0x0F);



}
void Data(uint8_t data)  
{
HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET);// RS pin high
Cmd4bit(data >> 4);
	HAL_Delay(1);
Cmd4bit(data & 0x0F);
	

}
void lcd_init() 
{
	

Cmd(0x03);
HAL_Delay(20);	

Cmd(0x03);
HAL_Delay(10);	

 	
Cmd(0x03);			// 4bit inerface
HAL_Delay(1);	

Cmd(0x02);			// 4bit inerface
HAL_Delay(1);	
	
	
Cmd(0x28);			// 4bit inerface
HAL_Delay(1);	
	
 	
Cmd(0x0C);			// Display on curser blinking
HAL_Delay(1);

Cmd(0x06);			// Display on curser blinking
HAL_Delay(1);


Cmd(0x01);			// 4bit inerface
HAL_Delay(100);	

Cmd(0x80);			// 4bit inerface
HAL_Delay(100);	
 
}


void  lcd_puts(char *str) 
{
 unsigned int i = 0;
	for(; str[i]!=0; i++)
	Data(str[i]);
	HAL_Delay(1);
}

int displayAscii(unsigned char position,float number)
{
char ascii[5];
sprintf(ascii,"%.2f",number);
Cmd(position);	
lcd_puts(ascii);
return(0);
}
